/**
 * ============================================
 * 풍무 모두모아 - 고객관리 시스템 백엔드
 * 구글시트: 고객상담
 * 계정: thinktree79@gmail.com
 *
 * [업데이트 내역]
 * - 메모(포스트잇) 기능 추가: 메모 시트 + getMemos/addMemo/updateMemo/deleteMemo
 * - 일정 등록 시 구글 캘린더(기본 캘린더)에도 자동 등록되도록 addSchedule 수정
 * - 일정 삭제 시 연결된 캘린더 이벤트도 함께 삭제되도록 deleteSchedule 수정
 * ============================================
 *
 * 사용 방법
 * 1. 이 코드를 전체 복사해서 Apps Script 편집기(Code.gs)에 붙여넣기 (기존 내용은 지우고)
 * 2. 상단 함수 선택 드롭다운에서 initializeSheets 선택 → ▶ 실행 버튼 클릭
 * 3. 권한 승인 창이 뜨면 "고급" → "이동(안전하지 않음)" → 허용
 *    (이번에는 캘린더 접근 권한도 함께 승인해달라는 창이 뜰 수 있어요. 허용해주세요.)
 * 4. 실행 후 구글시트로 돌아가면 매물 / 고객 / 상담이력 / 일정 / 메모 탭이 자동 생성됨
 * 5. 배포 → 배포 관리 → 기존 배포 옆 연필(수정) 아이콘 클릭 → 버전: "새 버전" 선택 → 배포
 *    (완전히 새 배포를 만들면 URL이 바뀌어서 프론트엔드가 연결이 끊겨요. 반드시 "수정"으로 새 버전만 올려주세요.)
 */

// ===================== 초기 설정 =====================

function initializeSheets() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();

  createSheetIfNotExists(ss, '매물', [
    '매물번호', '등록일', '매물상태', '거래유형', '종류', '건물명', '동', '해당층/전체층', '호수',
    '방향', '타입', '공급면적', '전용면적', '구조', '월세', '전세', '매매가',
    '기타사항', '옵션', '만기일자', '공실여부', '세입자연락처', '메모1',
    '임대인', '통신사', '임대인연락처', '연락처2', '상담메모', '광고유무'
  ]);

  createSheetIfNotExists(ss, '고객', [
    '고객ID', '등록일', '이름', '연락처', '유형',
    '희망지역', '희망평수', '희망가격대', '상태', '최근연락일', '메모',
    '건물명', '연결매물번호'
  ]);

  createSheetIfNotExists(ss, '상담이력', [
    '이력ID', '고객ID', '고객이름', '매물번호', '날짜시간', '유형', '상담내용', '다음할일', '다음예정일'
  ]);

  createSheetIfNotExists(ss, '일정', [
    '일정ID', '날짜', '시간', '제목', '메모', '캘린더이벤트ID'
  ]);

  createSheetIfNotExists(ss, '메모', [
    '메모ID', '제목', '내용', '색깔', '고정여부', '생성일시', '수정일시', '연결고객ID', '연결고객이름'
  ]);

  createSheetIfNotExists(ss, '사진', [
    '사진ID', '매물번호', '파일명', '드라이브파일ID', '공유링크', '업로드일시'
  ]);

  createSheetIfNotExists(ss, '문자템플릿', [
    '템플릿ID', '카테고리', '제목', '내용'
  ]);
  seedDefaultTemplates(ss);

  createSheetIfNotExists(ss, '아파트정보', [
    '단지명', '시공사', '입주일', '총세대수', '타입', '세대수', '전용면적', '공급면적', '계약면적', '최저분양가', '최고분양가', '비고'
  ]);
  seedApartmentInfo(ss);

  setupSortedView(ss);
  setupCategoryViews(ss);

  SpreadsheetApp.getUi().alert('시트 초기 설정이 완료되었습니다. 매물 / 고객 / 상담이력 / 일정 / 메모 / 사진 / 문자템플릿 / 아파트정보 탭을 확인하세요.');
}

function setupCategoryViews(ss) {
  var views = [
    { name: '매물_아파트', formula: '=QUERY(매물!A:AC,"select * where E=\'아파트\'",1)' },
    { name: '매물_오피스텔', formula: '=QUERY(매물!A:AC,"select * where E=\'오피스텔\'",1)' },
    { name: '매물_상가', formula: '=QUERY(매물!A:AC,"select * where E=\'상가\'",1)' },
    { name: '매물_기타', formula: '=QUERY(매물!A:AC,"select * where A is not null and E!=\'아파트\' and E!=\'오피스텔\' and E!=\'상가\'",1)' }
  ];

  views.forEach(function (v) {
    var sheet = ss.getSheetByName(v.name);
    if (!sheet) {
      sheet = ss.insertSheet(v.name);
    }
    sheet.getRange('A1').setValue('자동 분류 뷰입니다 (수식이 들어있어 직접 수정하지 마세요)');
    sheet.getRange('A1').setFontWeight('bold').setFontColor('#B5563C');
    sheet.getRange('A2').setFormula(v.formula);
  });
}

function setupSortedView(ss) {
  var sheet = ss.getSheetByName('상담이력_정리');
  if (!sheet) {
    sheet = ss.insertSheet('상담이력_정리');
  }
  sheet.getRange('A1').setValue('고객이름순으로 자동 정렬된 상담이력입니다 (수식이 들어있어 직접 수정하지 마세요)');
  sheet.getRange('A1').setFontWeight('bold').setFontColor('#B5563C');
  sheet.getRange('A2').setFormula(
    '=QUERY(상담이력!A:I,"select * where A is not null order by C asc, E desc",1)'
  );
}

function createSheetIfNotExists(ss, name, headers) {
  var sheet = ss.getSheetByName(name);
  if (!sheet) {
    sheet = ss.insertSheet(name);
    sheet.appendRow(headers);
    sheet.getRange(1, 1, 1, headers.length).setFontWeight('bold').setBackground('#e8eef7');
    sheet.setFrozenRows(1);
    sheet.autoResizeColumns(1, headers.length);
  } else {
    // 기존 시트가 있는데 헤더가 부족하면 (기존 사용자용 마이그레이션) 뒤에 이어붙임
    var existingHeaders = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
    headers.forEach(function (h) {
      if (existingHeaders.indexOf(h) === -1) {
        sheet.getRange(1, sheet.getLastColumn() + 1).setValue(h);
      }
    });
  }
  return sheet;
}

// ===================== 웹앱 진입점 =====================

function doGet(e) {
  var action = e.parameter.action;
  var result;

  try {
    switch (action) {
      case 'getProperties':
        result = { success: true, data: getSheetData('매물') };
        break;
      case 'getCustomers':
        result = { success: true, data: getSheetData('고객') };
        break;
      case 'getConsultations':
        result = { success: true, data: getConsultations(e.parameter.customerId) };
        break;
      case 'searchCustomers':
        result = { success: true, data: searchCustomers(e.parameter.query) };
        break;
      case 'addCustomer':
        result = addCustomer(JSON.parse(e.parameter.data));
        break;
      case 'updateCustomer':
        result = updateCustomer(JSON.parse(e.parameter.data));
        break;
      case 'addProperty':
        result = addProperty(JSON.parse(e.parameter.data));
        break;
      case 'getSchedules':
        result = { success: true, data: getSheetData('일정') };
        break;
      case 'addSchedule':
        result = addSchedule(JSON.parse(e.parameter.data));
        break;
      case 'deleteSchedule':
        result = deleteSchedule(e.parameter.id);
        break;
      case 'addConsultation':
        result = addConsultation(JSON.parse(e.parameter.data));
        break;
      case 'deleteConsultation':
        result = deleteConsultation(e.parameter.id);
        break;
      case 'getMemos':
        result = { success: true, data: getSheetData('메모') };
        break;
      case 'addMemo':
        result = addMemo(JSON.parse(e.parameter.data));
        break;
      case 'updateMemo':
        result = updateMemo(JSON.parse(e.parameter.data));
        break;
      case 'deleteMemo':
        result = deleteMemo(e.parameter.id);
        break;
      case 'getPropertyPhotos':
        result = { success: true, data: getPropertyPhotos(e.parameter.propertyId) };
        break;
      case 'deletePropertyPhoto':
        result = deletePropertyPhoto(e.parameter.id);
        break;
      case 'getTemplates':
        result = { success: true, data: getSheetData('문자템플릿') };
        break;
      case 'addTemplate':
        result = addTemplate(JSON.parse(e.parameter.data));
        break;
      case 'updateTemplate':
        result = updateTemplate(JSON.parse(e.parameter.data));
        break;
      case 'deleteTemplate':
        result = deleteTemplate(e.parameter.id);
        break;
      case 'getApartmentInfo':
        result = { success: true, data: searchApartmentInfo(e.parameter.query) };
        break;
      case 'getKimMokguApartments':
        result = { success: true, data: getSheetData('김목구아파트') };
        break;
      default:
        result = { success: false, message: '알 수 없는 action: ' + action };
    }
  } catch (err) {
    result = { success: false, message: err.toString() };
  }

  return ContentService
    .createTextOutput(JSON.stringify(result))
    .setMimeType(ContentService.MimeType.JSON);
}

// 사진 업로드는 base64 데이터 용량이 커서 GET 쿼리스트링으로 못 보내므로 POST로 처리
function doPost(e) {
  var result;
  try {
    var body = JSON.parse(e.postData.contents);
    var action = body.action;

    switch (action) {
      case 'addPropertyPhoto':
        result = addPropertyPhoto(body);
        break;
      default:
        result = { success: false, message: '알 수 없는 action: ' + action };
    }
  } catch (err) {
    result = { success: false, message: err.toString() };
  }

  return ContentService
    .createTextOutput(JSON.stringify(result))
    .setMimeType(ContentService.MimeType.JSON);
}

// ===================== 공통 유틸 =====================

function getSheetData(sheetName) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(sheetName);
  var values = sheet.getDataRange().getValues();
  var headers = values[0];
  var rows = [];
  for (var i = 1; i < values.length; i++) {
    var row = {};
    for (var j = 0; j < headers.length; j++) {
      row[headers[j]] = normalizeDateValue(values[i][j]);
    }
    rows.push(row);
  }
  return rows;
}

// 구글시트가 날짜 문자열을 자동으로 Date 객체로 바꿔버리는 문제 방지용
// (날짜 값이면 항상 'yyyy-MM-dd HH:mm' 형식의 문자열로 통일)
function normalizeDateValue(val) {
  if (val instanceof Date) {
    // 시간만 입력된 값(예: "14:30")은 시트가 날짜 원점(1899-12-30)을 붙여서 저장함 → 시간만 추출
    if (val.getFullYear() === 1899 && val.getMonth() === 11 && val.getDate() === 30) {
      return Utilities.formatDate(val, 'GMT+9', 'HH:mm');
    }
    return Utilities.formatDate(val, 'GMT+9', 'yyyy-MM-dd HH:mm');
  }
  return val;
}

function generateId(prefix) {
  return prefix + Utilities.formatDate(new Date(), 'GMT+9', 'yyMMddHHmmss');
}

// ===================== 일정 관련 (+ 구글 캘린더 연동) =====================

function addSchedule(data) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('일정');
  var id = generateId('S');

  var calendarEventId = '';
  try {
    calendarEventId = createCalendarEvent(data);
  } catch (err) {
    // 캘린더 등록이 실패해도 일정 자체는 시트에 저장되도록 함 (권한 미승인 등 예외 대응)
    calendarEventId = '';
  }

  sheet.appendRow([id, data.날짜 || '', data.시간 || '', data.제목 || '', data.메모 || '', calendarEventId]);
  return { success: true, id: id, calendarSynced: !!calendarEventId };
}

// 날짜+시간이 있으면 1시간짜리 일정으로, 시간이 없으면 종일 일정으로 캘린더에 등록
function createCalendarEvent(data) {
  if (!data.날짜) return '';
  var cal = CalendarApp.getDefaultCalendar();
  var title = data.제목 || '(제목없음)';
  var desc = data.메모 || '';
  var event;

  if (data.시간) {
    var start = new Date(data.날짜 + 'T' + data.시간 + ':00');
    var end = new Date(start.getTime() + 60 * 60 * 1000); // 1시간짜리 일정으로 등록
    event = cal.createEvent(title, start, end, { description: desc });
  } else {
    var day = new Date(data.날짜 + 'T00:00:00');
    event = cal.createAllDayEvent(title, day, { description: desc });
  }
  return event.getId();
}

function deleteSchedule(scheduleId) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('일정');
  var values = sheet.getDataRange().getValues();
  var headers = values[0];
  var idCol = headers.indexOf('일정ID');
  var calCol = headers.indexOf('캘린더이벤트ID');

  for (var i = 1; i < values.length; i++) {
    if (values[i][idCol] === scheduleId) {
      var eventId = calCol > -1 ? values[i][calCol] : '';
      if (eventId) {
        try {
          var event = CalendarApp.getDefaultCalendar().getEventById(eventId);
          if (event) event.deleteEvent();
        } catch (err) {
          // 캘린더 이벤트가 이미 지워졌거나 접근 불가해도 시트 삭제는 계속 진행
        }
      }
      sheet.deleteRow(i + 1);
      return { success: true };
    }
  }
  return { success: false, message: '해당 일정을 찾을 수 없습니다.' };
}

// ===================== 메모 관련 =====================

function addMemo(data) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('메모');
  var id = generateId('M');
  var now = Utilities.formatDate(new Date(), 'GMT+9', 'yyyy-MM-dd HH:mm');

  sheet.appendRow([
    id,
    data.제목 || '',
    data.내용 || '',
    data.색깔 || '노랑',
    data.고정여부 || 'N',
    now,
    now,
    data.연결고객ID || '',
    data.연결고객이름 || ''
  ]);

  return { success: true, id: id };
}

function updateMemo(data) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('메모');
  var values = sheet.getDataRange().getValues();
  var headers = values[0];
  var idCol = headers.indexOf('메모ID');
  var modCol = headers.indexOf('수정일시');

  for (var i = 1; i < values.length; i++) {
    if (values[i][idCol] === data.메모ID) {
      headers.forEach(function (h, colIdx) {
        if (data[h] !== undefined && h !== '메모ID') {
          sheet.getRange(i + 1, colIdx + 1).setValue(data[h]);
        }
      });
      if (modCol > -1) {
        sheet.getRange(i + 1, modCol + 1).setValue(Utilities.formatDate(new Date(), 'GMT+9', 'yyyy-MM-dd HH:mm'));
      }
      return { success: true };
    }
  }
  return { success: false, message: '해당 메모를 찾을 수 없습니다.' };
}

function deleteMemo(memoId) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('메모');
  var values = sheet.getDataRange().getValues();
  var idCol = values[0].indexOf('메모ID');

  for (var i = 1; i < values.length; i++) {
    if (values[i][idCol] === memoId) {
      sheet.deleteRow(i + 1);
      return { success: true };
    }
  }
  return { success: false, message: '해당 메모를 찾을 수 없습니다.' };
}

// ===================== 매물 사진 (구글 드라이브 연동) =====================

var PHOTO_ROOT_FOLDER_NAME = '고객관리_매물사진';

function getOrCreateFolder(name, parentFolder) {
  var parent = parentFolder || DriveApp.getRootFolder();
  var folders = parent.getFoldersByName(name);
  if (folders.hasNext()) {
    return folders.next();
  }
  return parent.createFolder(name);
}

function addPropertyPhoto(data) {
  var propertyId = data.propertyId;
  var fileName = data.fileName || ('사진_' + Utilities.formatDate(new Date(), 'GMT+9', 'yyMMddHHmmss'));
  var mimeType = data.mimeType || 'image/jpeg';
  var base64Data = data.base64Data;

  if (!propertyId || !base64Data) {
    return { success: false, message: '매물번호와 사진 데이터가 필요합니다.' };
  }

  var rootFolder = getOrCreateFolder(PHOTO_ROOT_FOLDER_NAME, DriveApp.getRootFolder());
  var propertyFolder = getOrCreateFolder(propertyId, rootFolder);

  var decoded = Utilities.base64Decode(base64Data);
  var blob = Utilities.newBlob(decoded, mimeType, fileName);
  var file = propertyFolder.createFile(blob);

  // 링크가 있는 사람은 누구나 볼 수 있게 설정 (고객에게 링크 공유용)
  file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);

  var shareLink = file.getUrl();
  var fileId = file.getId();
  var now = Utilities.formatDate(new Date(), 'GMT+9', 'yyyy-MM-dd HH:mm');

  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('사진');
  var id = generateId('PH');
  sheet.appendRow([id, propertyId, fileName, fileId, shareLink, now]);

  return {
    success: true,
    id: id,
    fileId: fileId,
    shareLink: shareLink,
    viewUrl: 'https://drive.google.com/uc?export=view&id=' + fileId,
    downloadUrl: 'https://drive.google.com/uc?export=download&id=' + fileId
  };
}

function getPropertyPhotos(propertyId) {
  var all = getSheetData('사진');
  var filtered = propertyId ? all.filter(function (r) { return r['매물번호'] === propertyId; }) : all;
  return filtered.map(function (r) {
    return {
      사진ID: r['사진ID'],
      매물번호: r['매물번호'],
      파일명: r['파일명'],
      공유링크: r['공유링크'],
      업로드일시: r['업로드일시'],
      viewUrl: 'https://drive.google.com/uc?export=view&id=' + r['드라이브파일ID'],
      downloadUrl: 'https://drive.google.com/uc?export=download&id=' + r['드라이브파일ID']
    };
  }).sort(function (a, b) { return new Date(b['업로드일시']) - new Date(a['업로드일시']); });
}

function deletePropertyPhoto(photoId) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('사진');
  var values = sheet.getDataRange().getValues();
  var headers = values[0];
  var idCol = headers.indexOf('사진ID');
  var fileIdCol = headers.indexOf('드라이브파일ID');

  for (var i = 1; i < values.length; i++) {
    if (values[i][idCol] === photoId) {
      var driveFileId = values[i][fileIdCol];
      try {
        if (driveFileId) DriveApp.getFileById(driveFileId).setTrashed(true);
      } catch (err) {
        // 드라이브 파일이 이미 삭제됐어도 시트 정리는 계속 진행
      }
      sheet.deleteRow(i + 1);
      return { success: true };
    }
  }
  return { success: false, message: '해당 사진을 찾을 수 없습니다.' };
}

// ===================== 매물 관련 =====================

function addProperty(data) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('매물');
  var id = generateId('P');
  var today = Utilities.formatDate(new Date(), 'GMT+9', 'yyyy-MM-dd');
  var regDate = data.등록일 || today;

  sheet.appendRow([
    id, regDate, data.매물상태 || '진행', data.거래유형 || '', data.종류 || '', data.건물명 || '', data.동 || '',
    data['해당층/전체층'] || '', data.호수 || '', data.방향 || '', data.타입 || '',
    data.공급면적 || '', data.전용면적 || '', data.구조 || '',
    data.월세 || '', data.전세 || '', data.매매가 || '',
    data.기타사항 || '', data.옵션 || '', data.만기일자 || '', data.공실여부 || '', data.세입자연락처 || '',
    data.메모1 || '', data.임대인 || '', data.통신사 || '', data.임대인연락처 || '', data.연락처2 || '', data.상담메모 || '',
    data.광고유무 || '아니오'
  ]);

  return { success: true, id: id };
}

// ===================== 고객 관련 =====================

function searchCustomers(query) {
  var all = getSheetData('고객');
  if (!query) return all;
  query = query.toString().trim();
  return all.filter(function (c) {
    return (c['이름'] && c['이름'].toString().indexOf(query) !== -1) ||
           (c['연락처'] && c['연락처'].toString().indexOf(query) !== -1);
  });
}

function addCustomer(data) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('고객');
  var id = generateId('C');
  var today = Utilities.formatDate(new Date(), 'GMT+9', 'yyyy-MM-dd');
  var regDate = data.등록일 || today;

  sheet.appendRow([
    id, regDate, data.이름 || '', data.연락처 || '', data.유형 || '',
    data.희망지역 || '', data.희망평수 || '', data.희망가격대 || '',
    data.상태 || '신규', data.최근연락일 || regDate, data.메모 || '',
    data.건물명 || '', data.연결매물번호 || ''
  ]);

  return { success: true, id: id };
}

function updateCustomer(data) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('고객');
  var values = sheet.getDataRange().getValues();
  var headers = values[0];
  var idCol = headers.indexOf('고객ID');

  for (var i = 1; i < values.length; i++) {
    if (values[i][idCol] === data.고객ID) {
      headers.forEach(function (h, colIdx) {
        if (data[h] !== undefined && h !== '고객ID') {
          sheet.getRange(i + 1, colIdx + 1).setValue(data[h]);
        }
      });
      return { success: true };
    }
  }
  return { success: false, message: '고객을 찾을 수 없습니다.' };
}

// ===================== 상담이력 관련 =====================

function getConsultations(customerId) {
  var all = getSheetData('상담이력');
  var filtered = customerId ? all.filter(function (r) { return r['고객ID'] === customerId; }) : all;
  return filtered.sort(function (a, b) { return new Date(b['날짜시간']) - new Date(a['날짜시간']); });
}

function addConsultation(data) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('상담이력');
  var id = generateId('H');
  var now = data.날짜시간 || Utilities.formatDate(new Date(), 'GMT+9', 'yyyy-MM-dd HH:mm');

  sheet.appendRow([
    id, data.고객ID || '', data.고객이름 || '', data.매물번호 || '',
    now, data.유형 || '기타', data.상담내용 || '', data.다음할일 || '', data.다음예정일 || ''
  ]);

  // 고객 시트의 최근연락일 업데이트 + 신규 고객이면 상담중으로 자동 전환
  if (data.고객ID) {
    var updatePayload = { 고객ID: data.고객ID, 최근연락일: now };
    var customers = getSheetData('고객');
    var cust = customers.filter(function (c) { return c['고객ID'] === data.고객ID; })[0];
    if (cust && cust['상태'] === '신규') {
      updatePayload.상태 = '상담중';
    }
    updateCustomer(updatePayload);
  }

  return { success: true, id: id };
}

function deleteConsultation(historyId) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('상담이력');
  var values = sheet.getDataRange().getValues();
  var idCol = values[0].indexOf('이력ID');

  for (var i = 1; i < values.length; i++) {
    if (values[i][idCol] === historyId) {
      sheet.deleteRow(i + 1);
      return { success: true };
    }
  }
  return { success: false, message: '해당 상담 기록을 찾을 수 없습니다.' };
}

// ===================== 문자템플릿 관련 =====================

function seedDefaultTemplates(ss) {
  var sheet = ss.getSheetByName('문자템플릿');
  if (sheet.getLastRow() > 1) return;

  var defaults = [
    ['신규매물안내', '신규 매물 안내', '안녕하세요 {{고객이름}}님, {{중개소명}}입니다 :)\n문의하셨던 조건에 맞는 매물이 새로 나와서 안내드려요!\n{{건물명}} · {{가격대}}\n관심 있으시면 편하실 때 연락 주세요. 감사합니다.'],
    ['계약만기안내', '계약 만기 안내', '안녕하세요 {{고객이름}}님, {{중개소명}}입니다.\n계약 만기일이 얼마 남지 않아 미리 안내드려요.\n재계약이나 이사 계획 있으시면 편하게 말씀해 주세요 :)'],
    ['방문감사', '방문 감사', '{{고객이름}}님, 오늘 방문해 주셔서 감사합니다!\n궁금하신 점 있으시면 언제든 편하게 연락 주세요.\n좋은 하루 보내세요 :)'],
    ['계약감사', '계약 감사', '{{고객이름}}님, 계약 진행해 주셔서 진심으로 감사드립니다.\n입주 관련해서도 제가 꼼꼼히 챙겨드릴게요.\n궁금한 점은 언제든 연락 주세요!'],
    ['광고재등록', '광고 재등록 안내', '{{건물명}} 매물 광고 재등록 안내드립니다.\n현재 조건 그대로 다시 올려도 괜찮으실까요?\n가격이나 조건 변경 있으시면 알려주세요.'],
    ['생일축하', '생일 축하', '{{고객이름}}님, 생신 진심으로 축하드립니다!\n항상 건강하시고 좋은 일만 가득하시길 바라요 :)'],
    ['임대인전화요청', '임대인 통화 요청', '{{고객이름}}님, 안녕하세요. {{건물명}} 관련해서 여쭤볼 게 있어 연락드렸어요.\n편하실 때 통화 가능하실까요?']
  ];

  defaults.forEach(function (d) {
    var id = 'T' + Utilities.formatDate(new Date(), 'GMT+9', 'yyMMddHHmmss') + Math.floor(Math.random() * 1000);
    sheet.appendRow([id, d[0], d[1], d[2]]);
    Utilities.sleep(10);
  });
}

function addTemplate(data) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('문자템플릿');
  var id = generateId('T');
  sheet.appendRow([id, data.카테고리 || '기타', data.제목 || '', data.내용 || '']);
  return { success: true, id: id };
}

function updateTemplate(data) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('문자템플릿');
  var values = sheet.getDataRange().getValues();
  var idCol = values[0].indexOf('템플릿ID');

  for (var i = 1; i < values.length; i++) {
    if (values[i][idCol] === data.템플릿ID) {
      if (data.카테고리 !== undefined) sheet.getRange(i + 1, 2).setValue(data.카테고리);
      if (data.제목 !== undefined) sheet.getRange(i + 1, 3).setValue(data.제목);
      if (data.내용 !== undefined) sheet.getRange(i + 1, 4).setValue(data.내용);
      return { success: true };
    }
  }
  return { success: false, message: '템플릿을 찾을 수 없습니다.' };
}

function deleteTemplate(templateId) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('문자템플릿');
  var values = sheet.getDataRange().getValues();
  var idCol = values[0].indexOf('템플릿ID');

  for (var i = 1; i < values.length; i++) {
    if (values[i][idCol] === templateId) {
      sheet.deleteRow(i + 1);
      return { success: true };
    }
  }
  return { success: false, message: '해당 템플릿을 찾을 수 없습니다.' };
}

// ===================== 아파트정보 관련 =====================

function seedApartmentInfo(ss) {
  var sheet = ss.getSheetByName('아파트정보');
  if (sheet.getLastRow() > 1) return;

  var rows = [
    ['신검단중앙역 풍경채어바니티','풍경채','2024.11',1425,'84A',534,84.7571,109.8431,162.8148,464000000,478000000,'발코니확장 9,425,000'],
    ['신검단중앙역 풍경채어바니티','풍경채','2024.11',1425,'84B',340,84.8181,109.7967,162.8065,410000000,469000000,'발코니확장 7,795,000'],
    ['신검단중앙역 풍경채어바니티','풍경채','2024.11',1425,'84C',169,84.9789,110.6605,163.7708,417000000,477000000,'발코니확장 7,854,000'],
    ['신검단중앙역 풍경채어바니티','풍경채','2024.11',1425,'111A',382,111.6084,143.585,213.3382,553000000,613000000,'발코니확장 9,128,000'],
    ['힐스테이트 검단 웰카운티','HILLSTATE(현대건설)','2025.01',1535,'74A',100,74.9929,96.8292,139.8383,null,null,''],
    ['힐스테이트 검단 웰카운티','HILLSTATE(현대건설)','2025.01',1535,'74B',50,74.8183,96.478,139.387,null,null,''],
    ['힐스테이트 검단 웰카운티','HILLSTATE(현대건설)','2025.01',1535,'84A',537,84.8216,108.1547,156.8008,null,null,''],
    ['힐스테이트 검단 웰카운티','HILLSTATE(현대건설)','2025.01',1535,'84B',75,84.8219,108.7496,157.3958,null,null,''],
    ['힐스테이트 검단 웰카운티','HILLSTATE(현대건설)','2025.01',1535,'84C',311,84.4775,108.9002,157.3488,null,null,''],
    ['힐스테이트 검단 웰카운티','HILLSTATE(현대건설)','2025.01',1535,'99A',219,99.4559,127.3991,184.438,null,null,''],
    ['금강펜테리움3차 센트럴파크','금강주택','2025.11',1049,'74',386,null,97.5598,149.4787,null,null,''],
    ['금강펜테리움3차 센트럴파크','금강주택','2025.11',1049,'84A',120,84.6955,109.6972,168.3596,null,null,''],
    ['금강펜테리움3차 센트럴파크','금강주택','2025.11',1049,'84B',226,84.6871,110.3769,169.0334,null,null,''],
    ['금강펜테리움3차 센트럴파크','금강주택','2025.11',1049,'98A',192,98.8376,127.9008,196.0771,null,null,''],
    ['금강펜테리움3차 센트럴파크','금강주택','2025.11',1049,'98B',125,98.8376,128.9882,197.4458,null,null,''],
    ['우미린클래스원','Lynn(우미건설)','2025.09',875,'84A',465,84.94,112.17,171.28,428300000,475900000,'발코니확장 5,000,000'],
    ['우미린클래스원','Lynn(우미건설)','2025.09',875,'84B',213,84.97,112.86,172.28,416400000,463400000,'발코니확장 3,290,000'],
    ['우미린클래스원','Lynn(우미건설)','2025.09',875,'84C',197,84.98,113.39,173.05,417100000,456800000,'발코니확장 7,470,000'],
    ['검단호수공원역 호반써밋','HOBAN SUMMIT','2026.03',856,'84A',497,84.6407,111.9762,171.7401,457100000,498600000,'발코니확장 5,460,000'],
    ['검단호수공원역 호반써밋','HOBAN SUMMIT','2026.03',856,'84B',165,84.6852,112.9309,172.6624,443000000,483400000,'발코니확장 6,400,000'],
    ['검단호수공원역 호반써밋','HOBAN SUMMIT','2026.03',856,'84C',194,84.8895,113.3305,172.9296,450700000,491800000,'발코니확장 5,130,000'],
    ['디에트르 더 에듀(대방5차)','D\'etre(대방건설)','2026.05',781,'59A',79,59.8673,85.0441,159.7754,430520000,470520000,'발코니확장 10,580,000'],
    ['디에트르 더 에듀(대방5차)','D\'etre(대방건설)','2026.05',781,'59B',176,59.8673,85.0441,159.7754,413970000,452270000,'발코니확장 8,830,000'],
    ['디에트르 더 에듀(대방5차)','D\'etre(대방건설)','2026.05',781,'59C',287,59.8448,85.5796,160.2829,386110000,421710000,'발코니확장 6,390,000'],
    ['디에트르 더 에듀(대방5차)','D\'etre(대방건설)','2026.05',781,'84A',20,84.6852,112.9309,218.6419,538010000,587610000,'발코니확장 11,990,000'],
    ['디에트르 더 에듀(대방5차)','D\'etre(대방건설)','2026.05',781,'84B',99,84.9159,113.4751,219.4742,514710000,562210000,'발코니확장 9,590,000'],
    ['디에트르 더 에듀(대방5차)','D\'etre(대방건설)','2026.05',781,'84C',120,84.8895,113.3305,219.2966,497360000,543160000,'발코니확장 7,640,000'],
    ['중흥S-클래스 에듀파크','S-CLASS(중흥건설)','2027.06',1448,'72A',100,72.8667,94.7176,147.1415,null,null,''],
    ['중흥S-클래스 에듀파크','S-CLASS(중흥건설)','2027.06',1448,'72B',108,72.38822,97.5405,149.6202,null,null,''],
    ['중흥S-클래스 에듀파크','S-CLASS(중흥건설)','2027.06',1448,'84A',526,84.55,109.3279,170.1574,null,null,''],
    ['중흥S-클래스 에듀파크','S-CLASS(중흥건설)','2027.06',1448,'84B',274,84.403,112.1626,172.8863,null,null,''],
    ['중흥S-클래스 에듀파크','S-CLASS(중흥건설)','2027.06',1448,'101',434,101.9805,131.0883,204.4581,null,null,''],
    ['중흥S-클래스 에듀파크','S-CLASS(중흥건설)','2027.06',1448,'147',6,147.9199,192.6818,299.1027,null,null,''],
    ['제일풍경채검단 3차','풍경채','2026.10',610,'84A',288,84.8523,111.1197,168.4443,483000000,522000000,'발코니확장 4,570,000'],
    ['제일풍경채검단 3차','풍경채','2026.10',610,'84B',95,84.9409,111.2162,168.6008,483000000,520000000,'발코니확장 3,230,000'],
    ['제일풍경채검단 3차','풍경채','2026.10',610,'84C',38,84.7533,110.8416,168.0995,481000000,520000000,'발코니확장 4,480,000'],
    ['제일풍경채검단 3차','풍경채','2026.10',610,'115A',109,115.9568,149.1951,227.5334,619000000,673000000,'발코니확장 4,770,000'],
    ['제일풍경채검단 3차','풍경채','2026.10',610,'115B',80,115.8589,149.5043,227.7765,635000000,678000000,'발코니확장 5,110,000'],
    ['제일풍경채검단 4차','풍경채','2027.02',1048,'84A',481,84.9343,110.0894,167.0368,493000000,549000000,'발코니확장 9,460,000'],
    ['제일풍경채검단 4차','풍경채','2027.02',1048,'84B',191,84.8582,110.308,167.2043,485000000,541000000,'발코니확장 8,980,000'],
    ['제일풍경채검단 4차','풍경채','2027.02',1048,'84C',98,84.8731,111.864,168.7703,478000000,536000000,'발코니확장 8,620,000'],
    ['제일풍경채검단 4차','풍경채','2027.02',1048,'110A',140,110.9706,144.1157,218.5201,611000000,688000000,'발코니확장 10,680,000'],
    ['제일풍경채검단 4차','풍경채','2027.02',1048,'110B',138,110.9098,144.8282,219.1918,634000000,688000000,'발코니확장 9,010,000'],
    ['힐스테이트 블로포레스트','HILLSTATE(현대건설)','2025.01',736,'84A',442,84.8616,110.5922,157.7126,null,null,''],
    ['힐스테이트 블로포레스트','HILLSTATE(현대건설)','2025.01',736,'84B',228,84.9857,111.6727,158.862,null,null,''],
    ['힐스테이트 블로포레스트','HILLSTATE(현대건설)','2025.01',736,'84C',66,84.8802,110.5201,157.6509,null,null,''],
    ['검단칸타빌더스위트','CANTAVIL','2026.06',625,'84A',262,84.9739,110.1537,158.1391,null,null,''],
    ['검단칸타빌더스위트','CANTAVIL','2026.06',625,'84B',181,84.9855,110.752,158.7439,null,null,''],
    ['검단칸타빌더스위트','CANTAVIL','2026.06',625,'84C',16,84.9908,109.5067,157.5016,null,null,''],
    ['검단칸타빌더스위트','CANTAVIL','2026.06',625,'84D',154,84.8686,109.9208,157.8467,null,null,''],
    ['검단칸타빌더스위트','CANTAVIL','2026.06',625,'97',6,97.8439,125.6943,180.9474,null,null,''],
    ['검단칸타빌더스위트','CANTAVIL','2026.06',625,'101',6,101.4436,129.8512,187.1372,null,null,'']
  ];

  rows.forEach(function(r){ sheet.appendRow(r); });
}

function searchApartmentInfo(query) {
  var all = getSheetData('아파트정보');
  if (!query) return all;
  query = query.toString().trim();
  return all.filter(function(a){
    return a['단지명'] && a['단지명'].toString().indexOf(query) !== -1;
  });
}
