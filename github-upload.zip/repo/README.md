# 풍무 모두모아 / 김목구부동산 - 업무 도구 모음

혼자 일하는 공인중개사(소공)를 위해 만든 도구들을 모아둔 저장소입니다.
Google Sheets + Google Apps Script를 백엔드로, 순수 HTML/JS 프론트엔드로 만들어져 있어
별도의 서버 비용 없이 운영할 수 있습니다.

## 폴더 구성

| 폴더 | 내용 |
|---|---|
| [`crm/`](./crm) | 고객관리 CRM — 고객/매물/상담이력/일정/사진/문자템플릿/매물비교 등 |
| [`image-tools/`](./image-tools) | 부동산 매물 이미지 제작 도구 (대표이미지·워터마크 등 6개 스타일) |
| [`image-tools-nextjs/`](./image-tools-nextjs) | 위 이미지 도구를 Next.js 프로젝트로 감싼 버전 (Vercel 배포용) |

## 공통 원칙

- 모든 개인 데이터는 개인 Google 계정(Google Sheets)에 저장됩니다 — 회사 계정이 아닌 개인 소유.
- 프론트엔드는 별도 빌드 과정 없는 단일 HTML 파일이라, Netlify 같은 곳에 파일을 그대로 드래그 앤 드롭하면 배포됩니다.
- 백엔드(Google Apps Script)는 무료로 운영 가능합니다.

## 배포 방법 (공통)

각 폴더의 README를 참고하세요. 기본 흐름은:
1. `index.html`을 Netlify(또는 Vercel)에 업로드
2. (CRM의 경우) `Code.gs`를 Google Apps Script 편집기에 붙여넣고 웹 앱으로 배포

## 히스토리

이 저장소는 Claude와의 대화를 통해 반복적으로 개발되었습니다. 기능이 추가될 때마다
`crm/index.html`, `crm/Code.gs`를 통째로 교체하는 방식으로 관리되고 있습니다.
