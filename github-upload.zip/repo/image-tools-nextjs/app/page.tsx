export default function Home() {
  return (
    <iframe
      src="/tool.html"
      title="김목구부동산 이미지 제작 도구"
      style={{
        border: 'none',
        width: '100vw',
        height: '100vh',
        display: 'block',
      }}
    />
  );
}
