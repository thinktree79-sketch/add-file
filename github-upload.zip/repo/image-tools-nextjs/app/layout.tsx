export const metadata = {
  title: '김목구부동산 이미지 제작 도구',
  description: '부동산 매물 대표이미지 / 상세컷 워터마크 제작 도구',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ko">
      <body style={{ margin: 0, padding: 0 }}>{children}</body>
    </html>
  );
}
