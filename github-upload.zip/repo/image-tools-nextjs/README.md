# 김목구부동산 이미지 제작 도구 (Next.js)

기존에 만든 캔버스 기반 이미지 제작 도구(`public/tool.html`)를 Next.js 프로젝트로 감싼 버전입니다.
도구 자체의 코드는 전혀 수정하지 않았고, Next.js가 그 파일을 화면 전체에 그대로 띄워주는 구조입니다.

## 폴더 구조

- `public/tool.html` — 원본 이미지 제작 도구 (집스타일/전면스타일/야경단지형/아라역형/워터마크 등 6개 스타일)
- `app/page.tsx` — 홈 화면. `tool.html`을 전체화면 iframe으로 표시
- `app/layout.tsx` — 기본 레이아웃

## 로컬에서 실행하기

```bash
npm install
npm run dev
```

브라우저에서 http://localhost:3000 접속

## 배포하기

### Vercel (추천, Next.js 만든 회사)
1. https://vercel.com 가입 (GitHub 계정으로 가능)
2. 이 폴더를 GitHub 저장소에 올리기
3. Vercel에서 "New Project" → 그 저장소 선택 → Deploy
4. 별도 설정 없이 자동으로 배포됨

### Netlify
1. `npm run build` 실행
2. Netlify에서 Next.js 프로젝트로 배포 (Netlify가 Next.js를 자동 인식함)

## 도구 자체를 수정하고 싶을 때

`public/tool.html` 파일 하나만 수정하면 됩니다. React 코드는 건드릴 필요 없습니다.
